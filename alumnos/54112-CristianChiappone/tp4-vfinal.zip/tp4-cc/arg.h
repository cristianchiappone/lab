#ifndef _arg_h_
#define _arg_h_

#include <getopt.h>

int get_opt(int argc, char** argv);

#endif