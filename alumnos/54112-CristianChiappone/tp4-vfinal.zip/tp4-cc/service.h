#ifndef _MY_SERVICE_H_
#define _MY_SERVICE_H_

int service(int sdc);

#endif
